<?
// $Id: echo.php 1364 2007-11-03 16:23:27Z jsakalos $

//sleep(8);
echo "<pre>" . print_r($_POST, 1) . "</pre>";
?>
