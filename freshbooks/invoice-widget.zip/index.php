<?php
require_once('FbInvoicePerformance.php');

$good		= 99999;
$bad		= 999;

$fbSpark 	= new FbInvoicePerformance();
$data 		= $fbSpark->getData();
$lastamount = $data[$fbSpark->lastmonth];
$amount 	= $data[$fbSpark->currentmonth];

function readout($val, $highThreshold, $lowThreshold){
	
	$html = '';

	if($val > $highThreshold){
		$html = '<span class="good">&pound;' . $lastamount . '</span>'; 
	} elseif($val < $highThreshold && $val > $lowThreshold){
		$html = '<span class="ok">&pound;' . $val . '</span>'; 
	} else {
		$html = '<span class="bad">&pound;' . $val . '</span>';
	}
	
	return $html;
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8">
	<title>Invoice Status</title>
	<style type="text/css" media="screen">
		body { font-size: 11px; font-family: verdana, sans-serif; padding-top: 60px;}
		.ok, .good, .bad { font-weight: bold;}
		.good { color: #009900;}
		.bad { color: #990000;}
	</style>
</head>
<table>
	<tr>
		<td rowspan="2">
			<img src="graph.php?good=<?php echo $good; ?>&amp;bad=<?php echo $bad; ?>" />
		</td>
		<td>Last Month: <?php echo readout($lastamount, $good, $bad); ?></td>
	</tr>
	<tr>
		<td>This Month: <?php echo readout($amount, $good, $bad); ?></td>
	</td>
</table>

