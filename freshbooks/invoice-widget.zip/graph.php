<?php
require_once('FbInvoicePerformance.php');
require_once('lib/Sparkline_Bar.php');

$fbSpark 	= new FbInvoicePerformance();
$months		= $fbSpark->getData();

$good 	= $_GET['good'];
$bad 	= $_GET['bad'];

$sparkline = new Sparkline_Bar();
$sparkline->SetBarWidth(3);
$sparkline->SetBarSpacing(2);

$loopMonth = $fbSpark->currentmonth + 1;

# twelve months, counting downwards so the oldest month appears first on the graph
for ($i = 12; $i > 0; $i--) {

  	if($months[$loopMonth] >= $good){
		$color = 'green';
	} elseif($months[$loopMonth] < $good && $months[$loopMonth] > $bad){
		$color = 'black';
	} else {
		$color = 'red';
	}

	$sparkline->SetData($loopMonth, $months[$loopMonth], $color);
	
    $loopMonth++;

	# if we go off the end of a year, loop back to the first month of the next year
	if($loopMonth > 12) {
		$loopMonth = 1;
	}
}

$sparkline->Render(30, 100);
$sparkline->Output();	

?>