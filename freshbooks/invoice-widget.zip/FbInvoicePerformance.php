<?php

class FbInvoicePerformance {
	
	public $endDate;	
	public $currentmonth;	
	public $lastmonth;	
	public $fbtoken = 'YOUR-API-TOKEN';	
	public $fburl = 'YOUR-API-URL';	

	function __construct($end = null) {
		if(is_null($end)){
			$end = date("Y-m-d");
		}
	
		$this->endDate = $end;
	}
	
	public function getData() {
		$today = $this->endDate;        
		$yearago = date("Y-m-d", mktime(0, 0, 0, date("m"),   date("d"),   date("Y")-1));     
		$currentmonth =  (int)substr($today, 5, 2);     
		$lastmonth =  $currentmonth - 1;    

		$this->currentmonth = (int)$currentmonth; 
		$this->lastmonth = (int)$lastmonth; 

		$xml = '<?xml version="1.0" encoding="utf-8"?>
		<request method="invoice.list">
		  <date_from>'.$yearago.'</date_from>   # Return invoices dated after this arg (Optional)
		  <date_to>'.$today.'</date_to>       # Return invoices dated before this arg (Optional)
		  <page>1</page>                      # Page number to return, default is 1 (Optional)
		  <per_page>1000</per_page>             # Number of results per page, default is 25 (Optional)
		</request>';

		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $this->fburl);
		curl_setopt($curl, CURLOPT_USERPWD, $this->fbtoken);
		curl_setopt($curl, CURLOPT_POST, 1);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 0);
		curl_setopt($curl, CURLOPT_TIMEOUT, 30);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $xml);
		$curl_result = curl_exec ($curl);
		curl_close ($curl);
		if (strlen($curl_result) < 2) return "Could not connect to FreshBooks server.";

		$returnXML = simplexml_load_string($curl_result);

		$months = array(
			1 => 0,
			2 => 0,
			3 => 0,
			4 => 0,
			5 => 0,
			6 => 0,
			7 => 0,
			8 => 0,
			9 => 0,
			10 => 0,
			11 => 0,
			12 => 0
		);

		if($returnXML->status == "fail") {
			
		} else {
			// assign the ID and continue
			foreach ($returnXML->invoices->children() as $invoice) {
				$month = (int)substr($invoice->date, 5, 2);
			   	$months[$month] = $months[$month] + $invoice->amount;
			}
		}

		return $months;
	}
}
?>